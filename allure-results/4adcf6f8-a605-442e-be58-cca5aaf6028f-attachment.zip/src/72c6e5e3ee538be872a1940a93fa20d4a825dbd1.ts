import{test,expect} from "@playwright/test"
import postAPIRequest from '../../test-data/api-request/POST_API_Request.json'

test.use({
    baseURL:process.env.Base_API_Url,
})

test("create post request with",async({request})=>{
    const postApiResponse=await request.post(`/booking`,{data:postAPIRequest})
    const jsonPOSTApiResponse=await postApiResponse.json();
    console.log('POST API Response: '+JSON.stringify(jsonPOSTApiResponse,null,2))


})
