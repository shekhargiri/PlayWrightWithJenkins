import{test,expect} from '@playwright/test'

test('Matching element in playwright',async({page})=>{
    await page.goto('https://testautomationpractice.blogspot.com/')
    const tableheader=await page.locator('[name="BookTable"] tbody tr td').allTextContents();
    console.log(tableheader);
    

})