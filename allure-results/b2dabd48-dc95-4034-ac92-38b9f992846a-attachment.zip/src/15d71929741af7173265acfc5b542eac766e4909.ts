import { test, expect, Locator } from "@playwright/test";
import { Page } from "@playwright/test";
import { LoginPage } from "../pages/LoginPage";
test.beforeAll(async()=>{
    console.log(`Running before all tests`)

});
test.beforeEach(async({page})=>{
    console.log(`Running before each tests`)
    

});

test.afterEach(async()=>{
    console.log(`Running after each tests`)
})
test.afterAll(async()=>{
    console.log(`Running after all tests`)
})
test("sauce demo login test with page object", async ({ page }) => {
    console.log(`Test 1 execution started`)
    const loginPage=new LoginPage(page);
    loginPage.goToUrl();
    loginPage.loginToSauceDemo();

 // await page.goto("https://www.saucedemo.com/");
  //await page.getByLabel("Username").fill("standard_user");
 // await page.getByPlaceholder("Password").fill("secret_sauce");
 // await page.locator("#login-button").click();
  await expect(page).toHaveTitle("Swag Labs");
  const prodCountLocator: Locator = page.locator(".inventory_item_label");
  const prodCount = await prodCountLocator.count();
  console.log(`Product counts: ${prodCount}`);
});

test("add first product", async ({ page }) => {
    console.log(`Test 2 execution started`)
  //await page.goto("https://www.saucedemo.com/");
  //await page.getByLabel("Username").fill("standard_user");
  //await page.getByPlaceholder("Password").fill("secret_sauce");
  //await page.locator("#login-button").click();
  await page.locator('[data-test="add-to-cart-sauce-labs-bolt-t-shirt"]').click();
  await page.locator('.shopping_cart_link').click();
  await expect(page.locator('.title')).toHaveText('Your Cart');

});
